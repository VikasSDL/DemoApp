﻿using Services;
using Repository;
using Microsoft.Extensions.DependencyInjection;

namespace Ioc
{
    public class DependencyContainer
    {
        public string newstr { get; set; }

        public static void RegisterServices(IServiceCollection services)
        {
            services.AddSingleton(typeof(IDapperResolver<>), typeof(DapperResolver<>));

            services.AddSingleton<IContactMasterRepository, ContactMasterRepository>();
            services.AddSingleton<IContactMasterService, ContactMasterService>();
        }
    }
}
