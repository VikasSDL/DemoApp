﻿namespace Model
{
    public class ContactMaster
    {
        public string ContactId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public ContactStatus Status { get; set; }
    }

    public class ContactMaster_Constants
    {
        public const string ContactId = "ContactId";
        public const string FirstName = "FirstName";
        public const string LastName = "LastName ";
        public const string EmailAddress = "EmailAddress";
        public const string PhoneNumber = "PhoneNumber";
        public const string Status = "Status";

        public const string sproc_Contact_AddEdit = "sproc_Contact_AddEdit";
        public const string sproc_Contact_Delete = "sproc_Contact_Delete";
        public const string sproc_Contact_List = "sproc_Contact_List";
        public const string sproc_Contact_UpdateStatus = "sproc_Contact_UpdateStatus";
        public const string sproc_Contact_Get = "sproc_Contact_Get";
    }

    public enum ContactStatus
    {
        Active = 1,
        Inactive = 0
    }
}
