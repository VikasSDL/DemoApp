﻿using Microsoft.AspNetCore.Mvc;
using Model;
using Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api
{

    public class ContactMasterController : Controller
    {
        private readonly IContactMasterService _contactMasterService;
        public ContactMasterController(IContactMasterService contactMasterService)
        {
            _contactMasterService = contactMasterService;
        }

        [HttpGet(ApiRoutes.ContactMaster.GetAllContacts)]
        [ProducesResponseType(typeof(List<ContactMaster>), statusCode: 200)]
        public async Task<IActionResult> ContactList([FromBody] ContactMaster request)
        {
            var ContactMasterList = await _contactMasterService.GetAllAsync(request);
            return Ok(ContactMasterList);
        }

        [HttpGet(ApiRoutes.ContactMaster.GetContact)]
        public async Task<IActionResult> GetContact([FromBody] ContactMaster request)
        {
            var obj = await _contactMasterService.GetAsync(request);
            return Ok(obj);
        }

        [HttpPost(ApiRoutes.ContactMaster.AddEditContact), DisableRequestSizeLimit]
        [ProducesResponseType(typeof(string), statusCode: 200)]
        public async Task<IActionResult> AddEditContact([FromBody] ContactMaster request)
        {
            var RetCnt = await _contactMasterService.AddEditAsync(request);
            return Ok(RetCnt);

        }

        [HttpPost(ApiRoutes.ContactMaster.DeleteContact), DisableRequestSizeLimit]
        [ProducesResponseType(typeof(string), statusCode: 200)]
        public async Task<IActionResult> DeleteContact([FromBody] ContactMaster request)
        {
            var RetCnt = await _contactMasterService.DeleteAsync(request);
            return Ok(RetCnt);

        }

        [HttpPost(ApiRoutes.ContactMaster.UpdateStatus)]
        [ProducesResponseType(typeof(int), statusCode: 200)]
        public async Task<IActionResult> UpdateStatus([FromBody] ContactMaster request)
        {
            var RetCnt = await _contactMasterService.UpdateStatus(request);
            return Ok(RetCnt);
        }

    }
}