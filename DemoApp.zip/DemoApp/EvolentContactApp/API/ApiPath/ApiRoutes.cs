﻿namespace Api
{
    public static class ApiRoutes
    {
        public const string Base = "api";

        public static class ContactMaster
        {
            public const string GetAllContacts = Base + "/contactmaster/getallcontacts";
            public const string GetContact = Base + "/contactmaster/getcontact";
            public const string AddEditContact = Base + "/contactmaster/addeditcontact";
            public const string UpdateStatus = Base + "/contactmaster/updatestatus";
            public const string DeleteContact = Base + "/contactmaster/deletecontact";
        }
    }
}


