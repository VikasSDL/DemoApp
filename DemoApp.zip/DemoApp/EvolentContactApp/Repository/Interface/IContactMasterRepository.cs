using Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repository
{
    public interface IContactMasterRepository : IRepository<ContactMaster>
    {
        Task<int> AddEditAsync(ContactMaster obj);
        Task<ContactMaster> GetAsync(ContactMaster obj);
        Task<IEnumerable<ContactMaster>> GetAllAsync(ContactMaster obj);
        Task<int> DeleteAsync(ContactMaster obj);
        Task<int> UpdateStatus(ContactMaster obj);
    }
}