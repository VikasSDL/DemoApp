﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public interface IRepository<T>
    {
        Task<int> ExecuteNonQueryAsync(T obj, string[] param, string spName);
        Task<T> GetAsync(T obj, string[] param, string spName);
        Task<IEnumerable<T>> GetAllAsync(T obj, string[] param, string spName);
    }
}
