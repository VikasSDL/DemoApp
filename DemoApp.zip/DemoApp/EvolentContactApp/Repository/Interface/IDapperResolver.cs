﻿using Dapper;

namespace Repository
{
    public interface IDapperResolver<T>
    {
        DynamicParameters GetParameters(string[] addParams, T entity);
    }
}
