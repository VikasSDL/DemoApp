using Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repository
{
    public class ContactMasterRepository : Repository<ContactMaster>, IContactMasterRepository
    {
        public ContactMasterRepository(IDapperResolver<ContactMaster> resolver) : base(resolver)
        {

        }

        public async Task<int> AddEditAsync(ContactMaster obj)
        {
            string[] addParams = new string[] {
                                                ContactMaster_Constants.ContactId,
                                                ContactMaster_Constants.FirstName,
                                                ContactMaster_Constants.LastName,
                                                ContactMaster_Constants.EmailAddress,
                                                ContactMaster_Constants.PhoneNumber,
                                                ContactMaster_Constants.Status
            };
            return await ExecuteNonQueryAsync(obj, addParams, ContactMaster_Constants.sproc_Contact_AddEdit);
        }

        public async Task<int> DeleteAsync(ContactMaster obj)
        {
            string[] addParams = new string[] { ContactMaster_Constants.ContactId };
            return await ExecuteNonQueryAsync(obj, addParams, ContactMaster_Constants.sproc_Contact_Delete);
        }

        public async Task<IEnumerable<ContactMaster>> GetAllAsync(ContactMaster obj)
        {
            return await GetAllAsync(obj, null, ContactMaster_Constants.sproc_Contact_List);
        }

        public async Task<ContactMaster> GetAsync(ContactMaster obj)
        {
            string[] addParams = new string[] { ContactMaster_Constants.ContactId };
            return await GetAsync(obj, addParams, ContactMaster_Constants.sproc_Contact_Get);
        }

        public async Task<int> UpdateStatus(ContactMaster obj)
        {
            string[] addParams = new string[] { ContactMaster_Constants.ContactId, ContactMaster_Constants.Status };
            return await ExecuteNonQueryAsync(obj, addParams, ContactMaster_Constants.sproc_Contact_UpdateStatus);
        }
    }
}
