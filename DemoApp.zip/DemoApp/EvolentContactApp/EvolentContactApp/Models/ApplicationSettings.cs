﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Utility
{
    public static class ApplicationSettings
    {
        public static string WebApiUrl { get; set; } = "http://localhost:56865";
    }
}
