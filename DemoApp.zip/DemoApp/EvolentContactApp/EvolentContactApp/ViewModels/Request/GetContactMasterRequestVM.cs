﻿namespace UIApp
{
    public class GetContactMasterRequestVM
    {
        public string ContactId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
