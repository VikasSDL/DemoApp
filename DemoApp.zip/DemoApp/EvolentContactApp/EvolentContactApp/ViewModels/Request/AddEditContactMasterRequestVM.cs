﻿using System.ComponentModel.DataAnnotations;

namespace UIApp
{
    public class AddEditContactMasterRequest
    {
        public string ContactId { get; set; }
        [Required(ErrorMessage = "Please enter First Name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please enter Last Name")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Please enter Email Address")]
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        [Required(ErrorMessage = "Please select Status")]
        public ContactStatus Status { get; set; }
    }

    public enum ContactStatus
    {
        Active = 1,
        Inactive = 0
    }
}
