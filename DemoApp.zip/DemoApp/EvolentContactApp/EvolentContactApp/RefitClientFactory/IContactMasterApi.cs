﻿using UIApp;
using Microsoft.AspNetCore.Http;
using Refit;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace RefitClientFactory
{
    [Headers("Authorization: Bearer")]
    public interface IContactMasterApi
    {
        [Get(path: "/api/contactmaster/getcontact")]
        Task<ApiResponse<GetContactMasterResponseVM>> GetContact(string ContactId);

        [Get(path: "/api/contactmaster/getallcontacts")]
        Task<ApiResponse<List<GetContactMasterResponseVM>>> GetAllContacts(GetContactMasterRequestVM model);

        [Post(path: "/api/contactmaster/addeditcontact")]
        Task<HttpResponseMessage> AddEditContact(AddEditContactMasterRequest request);

        [Post(path: "/api/contactmaster/deletecontact")]
        Task<HttpResponseMessage> DeleteContact(GetContactMasterRequestVM request);

        [Post(path: "/api/contactmaster/updatestatus")]
        Task<HttpResponseMessage> UpdateStatus(GetContactMasterRequestVM request);
    }
}
