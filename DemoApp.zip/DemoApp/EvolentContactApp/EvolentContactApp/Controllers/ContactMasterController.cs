﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Refit;
using RefitClientFactory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UIApp;
using Utility;

namespace EvolentContactApp.Controllers
{
    public class ContactMasterController : Controller
    {
        public async Task<IActionResult> ManageContacts()
        {
            var cachedToken = HttpContext.Session.GetBearerToken();
            var contactAPI = RestService.For<IContactMasterApi>(hostUrl: ApplicationSettings.WebApiUrl, new RefitSettings
            {
                AuthorizationHeaderValueGetter = () => Task.FromResult(cachedToken)
            });
            var apiResponse = await contactAPI.GetAllContacts(new GetContactMasterRequestVM());
            var response = apiResponse.Content;

            //ViewBag.lstDepartments = new SelectList(response.ListDepartments, "DepartmentId", "DepartmentName");

            List<GetContactMasterResponseVM> lstContacts = new List<GetContactMasterResponseVM>();
            lstContacts.Add(new GetContactMasterResponseVM() { ContactId = "C001", FirstName = "vikas", LastName = "shelake", PhoneNumber = "880455", EmailAddress = "vs@gmail.com", Status = ContactStatus.Active });
            lstContacts.Add(new GetContactMasterResponseVM() { ContactId = "C002", FirstName = "ramesh", LastName = "jindaal", PhoneNumber = "7747888777", EmailAddress = "rj@gmail.com", Status = ContactStatus.Inactive });

            return View(response);
        }

        public IActionResult GetContactList(string FirstName, string LastName)
        {
            List<GetContactMasterResponseVM> lstContacts = new List<GetContactMasterResponseVM>();
            lstContacts.Add(new GetContactMasterResponseVM() { ContactId = "C001", FirstName = "vikas", LastName = "shelake", PhoneNumber = "880455", EmailAddress = "vs@gmail.com", Status = ContactStatus.Active });
            lstContacts.Add(new GetContactMasterResponseVM() { ContactId = "C002", FirstName = "ramesh", LastName = "jindaal", PhoneNumber = "7747888777", EmailAddress = "rj@gmail.com", Status = ContactStatus.Inactive });
            return PartialView("_GetContactList", lstContacts);
        }

        public IActionResult AddEditContact(string ContactId)
        {
            GetContactMasterResponseVM obj = new GetContactMasterResponseVM() { ContactId = ContactId };
            obj.FirstName = "Vikas"; obj.LastName = "shelake"; obj.EmailAddress = "vikas@email.com"; obj.PhoneNumber = "5455555"; obj.Status = ContactStatus.Active;
            return View(obj);
        }

        [HttpPost]
        public IActionResult AddEditContact(GetContactMasterResponseVM obj)
        {
            return RedirectToAction("ManageContacts");
        }

        public IActionResult DeleteContact(string ContactId)
        {
            return Json(new { IsSucccess = true });
        }
    }
}
