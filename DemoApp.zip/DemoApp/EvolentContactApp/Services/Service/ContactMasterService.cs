using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Model;
using Repository;

namespace Services
{
    public class ContactMasterService : IContactMasterService
    {
        private IContactMasterRepository iContactMasterRepository;
        public ContactMasterService(IContactMasterRepository IContactMasterRepository) : base()
        {
            iContactMasterRepository = IContactMasterRepository;
        }

        public async Task<int> AddEditAsync(ContactMaster obj)
        {
            return await iContactMasterRepository.AddEditAsync(obj);
        }

        public async Task<int> DeleteAsync(ContactMaster obj)
        {
            return await iContactMasterRepository.DeleteAsync(obj);
        }

        public async Task<IEnumerable<ContactMaster>> GetAllAsync(ContactMaster obj)
        {
            return await iContactMasterRepository.GetAllAsync(obj);
        }

        public async Task<ContactMaster> GetAsync(ContactMaster obj)
        {
            return await iContactMasterRepository.GetAsync(obj);
        }

        public async Task<int> UpdateStatus(ContactMaster obj)
        {
            return await iContactMasterRepository.UpdateStatus(obj);
        }
    }
}
