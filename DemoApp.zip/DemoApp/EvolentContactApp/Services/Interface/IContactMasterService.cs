using Model;
using System.Threading.Tasks;

namespace Services
{
    public interface IContactMasterService : IServiceBase<ContactMaster>
    {
        Task<int> UpdateStatus(ContactMaster obj);
    }
}
