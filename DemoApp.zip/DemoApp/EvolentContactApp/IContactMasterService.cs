﻿using Model;

namespace Service
{
    public interface IContactMasterService : IServiceBase<ContactMaster>
    {

    }
}
